//variaveis do jogador
var jogador_x = 50 , jogador_y = 450, jogador_yp = 0, img_jogador = [];

//coordenadas do inimigo 1
var inimigo1_x = 1200, inimigo1_y = 530, img_inimigo = [];

//coordenadas do inimigo 2
var inimigo2_x = 1800, inimigo2_y = 530, img_inimigo = [];

//coordenadas do amigo
var amigo1_x = 1200, amigo1_y = 200, img_amigo = [];

//var tela
var tela = 0, tempo = 0, colisao = false ;

//variavel images
var img_fundo = []; 

//outras variaveis do jogo 

var velocidade = 2, cont = 0, nivel = 1, pontos = 0;

var pulo = false, pulo_y = 0; // coordendas do pulo

var pulo_x0, pulo_y0 = 0; // coordendas da origem do pulo
 
//variável musica

var song = [] 


function preload(){
    //imagens de fundo
    img_fundo[0] = loadImage('fundo0.JPG') //tela inicial
    
    img_fundo[1] = loadImage('fundo1.JPG') //tela de instruções

    img_fundo[2] = loadImage('fundo2.JPG') //tela do jogo
    
    img_fundo[3] = loadImage('fundo3.JPG') //tela de derrota
        
    img_fundo[4] = loadImage('fundo4.jpg') //tela de vitoria


    //jogador
    img_jogador[1] = loadImage('jogador1.png') //jogador estático
    img_jogador[2] = loadImage('jogador2.png') //jogador pulando
	
	//amigo
	img_amigo[1] = loadImage('amigo.png') //pokebola
	
    //inimigo
    img_inimigo[1] = loadImage('inimigo.png') //primeiro inimigo
    img_inimigo[2] = loadImage('inimigo2.png') //segundo inimigo
    
    //musica
    song[0] = loadSound('Pokemon theme song instrumental.mp3');
    
		
}

function setup(){
    createCanvas(1200,675); //tamanho da tela do jogo
    //song.play() //tocar a musica
    //song.setVolume(0.5) //volume da musica
}

function draw(){
	
    //tela inicial
   
		if(tela == 0){
			background(img_fundo[0]);
            	
            //condição para mudar a tela
		if (keyIsDown(ENTER) ) {
			tela = 1; 
		  } 
		    } 
    //fazer mudança de tela
    
		if(tela == 1){
			background(img_fundo[1]);
				
			//condição para mudar a tela
		if (keyIsDown(UP_ARROW) ) {
			tela = 2; 
		  } 
		    }
	//fazer mudança de tela	
    //tela dentro do jogo
    
        if(tela == 2){
			background(img_fundo[2]);
			

     //jogador
     //localização do jogador estatico, tamanho da imagem do jogador
        if(pulo == false){
            image(img_jogador[1], jogador_x, jogador_y, 200, 200)
        }
        if (keyIsDown(UP_ARROW) && (! pulo) ){ 
             pulo = true; 
             contFrames = 1; 
        }
        
      //movimentação do pulo, localização do jogador pulando, tamanho da figura
       
        if (pulo == true) {
             image(img_jogador[2], jogador_x, jogador_y + jogador_yp, 200, 230)
             contFrames++; // movimenta o pulo  
             jogador_yp = 0.8*(contFrames)*(contFrames - 45);
			 pulo_y0 = jogador_yp
											//Se o valor da amplitude do pulo for menor que zero
        if (jogador_yp >= 0) {
											// O pulo deve ser finalizado habilida a ocorrência de um novo pulo 
			pulo = false;
            jogador_yp = 450; 	
        }
        }
        
	//inimigo1
                
      image(img_inimigo[1],inimigo1_x,inimigo1_y, 120,120) 
      
    //inimigo2
                
      image(img_inimigo[2],inimigo2_x,inimigo2_y, 175,120) 
     
    //inimigo2_x = random (50000)  FUNCAO RANDOMICA
 
            
	//colisao (inimigo1)
	if( (Math.abs(inimigo1_x - jogador_x-100) < 1.2*nivel)  && (inimigo1_y == jogador_y+80 + pulo_y0) ) {
             pulo_y0 = 0
		     tela = 3
        }
             inimigo1_x = inimigo1_x - velocidade

		//condições para aumentar a velocidade do inimigo1 de acordo com os niveis
        if(inimigo1_x <= -100){
			 nivel = nivel+1
             inimigo1_x = 1250
        if (nivel==3 && nivel<=5){
			 velocidade = velocidade+1
			inimigo1_x = 1250
		}if (nivel==5 && nivel<=8){
			 velocidade = velocidade+1
			 inimigo1_x = 1250
		}if (nivel==8 && nivel<=15){
			 velocidade = velocidade+1
			 inimigo1_x = 1250
	    }if (nivel==15 && nivel <22){
			 velocidade = velocidade+0.5
			 inimigo1_x = 1250
	    }if (nivel==22){
			 velocidade = velocidade+0.1
			 inimigo1_x = 1250 
	    }
		}
		
		//colisao (inimigo2)
        
	if( (Math.abs(inimigo2_x - jogador_x-100) < 1.2*nivel)  && (inimigo2_y == jogador_y+80 + pulo_y0) ) {
             pulo_y0 = 0
		     tela = 3
        }
             inimigo2_x = inimigo2_x - velocidade 

		//condições para aumentar a velocidade do inimigo2 de acordo com os niveis
        if(inimigo2_x <= -100){
			 nivel = nivel + 1
             inimigo2_x = 1250
        if (nivel==3 && nivel<=5){
			 velocidade = velocidade+1
			inimigo2_x = 1250
		}if (nivel==5 && nivel<=8){
			 velocidade = velocidade+1
			 inimigo2_x = 1250
		}if (nivel==8 && nivel<=15){
			 velocidade = velocidade+1
			 inimigo2_x = 1250
	    }if (nivel==15 && nivel <22){
			 velocidade = velocidade+0.5
			 inimigo2_x = 1250
	    }if (nivel>22){
			 velocidade = velocidade+0.1
			 inimigo2_x = 1250
	    }
		}
               
	//amigo, coordenadas
			image(img_amigo[1],amigo1_x,amigo1_y, 40,40)
			amigo1_x = amigo1_x-20 //velocidade do amigo
	

	//colisao (amigo)
	
		if( (amigo1_x >50 && amigo1_x <200)  && ((jogador_y + pulo_y0) <= amigo1_y   ) ){
             pontos = pontos+1
          //condição para ganhar o jogo
              if (pontos === 151){
             tela = 4
             }
             amigo1_x = 1250
         }
         
         //condição para fazer o amigo retornar a tela
            if(amigo1_x < -100){
			amigo1_x = 1250;}
          //nivel e pontuação 
	        textSize(50); 
            fill(340,195,30);
            text((nivel), 150, 80);
            text((pontos), 1080,80);       
        }
        
       
          //tela de derrota    
        if(tela==3){			
			background(img_fundo[3]); 
			fill(236, 50, 103);
			textSize(40); 
			text((nivel),370,280);
			text((pontos),270,385);
        
			
		if (keyIsDown(ENTER) ) {
           window.location.reload()  // reinicia o jogo
        } 
		}
         //tela de vitoria
        if(tela==4){
            background(img_fundo[4]);
            
            
            if (keyIsDown(ENTER) ) {
           window.location.reload()  // reinicia o jogo
        }
            
        }
		
		}